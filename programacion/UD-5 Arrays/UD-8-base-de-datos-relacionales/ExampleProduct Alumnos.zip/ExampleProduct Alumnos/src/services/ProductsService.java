package services;

import java.sql.*;
import java.util.*;
import models.Products;

public class ProductsService {
   private final String tabla = "Productos";
   
   public void save(Connection conexion, Products product) throws SQLException{
      try{
         PreparedStatement consulta;
         if(product.getId() == null){
            consulta = conexion.prepareStatement("INSERT INTO " + this.tabla + "(nombre, precio) VALUES(?, ?)");
            consulta.setString(1, product.getNombre());
            consulta.setInt(2, product.getPrecio());
         }else{
            consulta = conexion.prepareStatement("UPDATE " + this.tabla + " SET nombre = ?, precio = ? WHERE id = ?");
            consulta.setString(1, product.getNombre());
            consulta.setInt(2, product.getPrecio());
            consulta.setInt(3, product.getId());
         }
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   
   public Products getProduct(Connection conexion, int id) throws SQLException {
      Products product = null;
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT nombre,precio "
                 + " FROM " + this.tabla + " WHERE id = ?" );
         consulta.setInt(1, id);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            product = new Products(id, resultado.getString("nombre"), 
                    resultado.getInt("precio"));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return product;
   }
   
   public void remove(Connection conexion, Products product) throws SQLException{
      try{
         PreparedStatement consulta = conexion.prepareStatement("DELETE FROM " 
      + this.tabla + " WHERE id = ?");
         consulta.setInt(1, product.getId());
         consulta.executeUpdate();
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
   }
   
   public List<Products> getAllProducts(Connection conexion) throws SQLException{
      List<Products> products = new ArrayList<>();
      try{
         PreparedStatement consulta = conexion.prepareStatement("SELECT id,nombre,precio "
                 + " FROM " + this.tabla);
         ResultSet resultado = consulta.executeQuery();
         while(resultado.next()){
            products.add(new Products(resultado.getInt("id"), resultado.getString("nombre"), 
                    resultado.getInt("precio")));
         }
      }catch(SQLException ex){
         throw new SQLException(ex);
      }
      return products;
   }
}